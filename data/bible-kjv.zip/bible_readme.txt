# bible.txt

Full text of the King James Bible. It contains all books of both the Old and the New Testament except deuterocanonical books. 
Each row is one verse from the Bible with structure:
* book name
* [one space]
* chapter number
* [one space]
* verse number
* [one tab character]
* verse text